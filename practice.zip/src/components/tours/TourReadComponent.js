import React, { useEffect, useState } from 'react';
import { API_SERVER_HOST } from '../../api/todoApi';
import useCustomMove from '../../hooks/useCustomMove';
import FetchingModal from '../common/FetchingModal';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/Card";
import { Calendar } from 'antd';
import { getOne } from '../../api/tourApi';

const initState = {
    tno: 0,
    tname: '',
    tcategoryName: '',
    tdesc: '',
    tprice: 0,
    tlocation: '',
    uploadFileNames: [],
    tDate: [],
    max_capacity: 0,
};

const TourReadComponent = ({ tno }) => {
    const [tour, setTour] = useState(initState);
    const { moveToList, moveToModify, page, size } = useCustomMove();
    const [calendarMode, setCalendarMode] = useState('month'); // 초기 모드는 월
    const [dateInfo,setDateInfo] = useState('')
    const [fetching, setFetching] = useState(false);
    const wrapperStyle = {
        width: 300,
        border: '1px solid #d9d9d9', 
        borderRadius: 4,
    };

    useEffect(() => {
        setFetching(true);

        getOne(tno).then(data => {
            setTour({
                ...initState, // 초기 상태를 유지하면서
                ...data, // data의 속성들로 덮어씀
                tDate: data.tdate // tDate만 명시적으로 설정
            });
            setFetching(false);
            console.log(data.tdate);
        });
    }, [tno]);

    const onPanelChange = (value, mode) => {
        setCalendarMode(mode); // 현재 모드를 업데이트
        console.log(value.format('YYYY-MM-DD'), mode);
    };

    //예약가능한 날짜만 밑줄 생기는 함수 
    const dateCellRender = (value) => {
        const formattedDate = value.format('YYYY-MM-DD');
        const checkDate = tour.tDate.find(date => date.tourDate === formattedDate); //서버에서 받아온 날짜와 일치하는 날짜를 체크 

        return (
            <div className={`${checkDate ? 'border-b-2 border-blue-500' : ''}`}></div>  //예약 가능한 날짜에만 밑줄, 클릭가능 
        );
    };

    //예약가능한 날짜만 선택할수 있게 하는 함수 
    const disabledDate = (current) => {
        
        if (calendarMode === 'year') {
            return false; //  년도 뷰에서는 활성화
        }
    
        // 날짜 뷰일 때만 예약된 날짜가 아닌 날짜를 비활성화
        const formattedDate = current.format('YYYY-MM-DD');
        return !tour.tDate.some(date => date.tourDate === formattedDate);
    };

    // //날짜 클릭시 날짜에 해당하는 예약 가능 인원 출력
    const onSelect = (e) => {
        console.log(e);
        console.log(e.format('YYYY-MM-DD'));
    
        const formattedDate = e.format('YYYY-MM-DD');
    
        // 예약 가능한 날짜 찾기
        setDateInfo(tour.tDate.find(i => i.tourDate === formattedDate))
    
        if (dateInfo) {
            console.log(dateInfo.tourDate); // 예약 가능한 경우, tourDate 속성만 출력
        } else {
            console.log("예약 불가"); // 예약 불가능한 경우
        }
    };
    

    return (
        <div className='grid grid-cols-3 gap-6 mt-10 m-4'>
            <Card className='col-span-2 border-2 p-4 rounded-lg shadow-md'>
                <CardHeader className="space-y-1">
                    {fetching ? <FetchingModal /> : null}
                    <div className='border w-20 rounded-2xl border-solid text-center font-bold mb-2'>No.{tour.tno}</div>
                    <CardTitle className='text-4xl font-bold'>{tour.tname}</CardTitle>
                </CardHeader>
                <CardContent>
                    <div style={wrapperStyle}>
                        <Calendar
                            fullscreen={false}
                            onPanelChange={onPanelChange}
                            cellRender={dateCellRender}
                            onSelect={onSelect}
                            disabledDate ={disabledDate}
                        />
                    </div>
                    <div>
                        최대 인원 : {tour.max_capacity}
                    </div>
                    <div>
                        {dateInfo ? <div>예약 가능 인원 : {dateInfo.available_capacity}</div> : '' }
                    </div>
                </CardContent>
                <CardFooter className="relative justify-between">
                </CardFooter>
            </Card>
        </div>
    );
}

export default TourReadComponent;
