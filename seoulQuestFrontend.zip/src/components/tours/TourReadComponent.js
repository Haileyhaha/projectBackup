import React, { useEffect, useState } from 'react';
import { API_SERVER_HOST } from '../../api/todoApi';
import useCustomMove from '../../hooks/useCustomMove';
import FetchingModal from '../common/FetchingModal';
// import useCustomCart from '../../hooks/useCustomCart';
// import useCustomLogin from '../../hooks/useCustomLogin';
// import CartComponent from '../menus/CartComponent';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/Card"
import { getOne } from '../../api/tourApi';
import { Calendar } from "antd";
import { MergeOutlined, ShoppingCartOutlined, UserOutlined} from '@ant-design/icons';

const initState = {
    tno: 0,
    tname: '',
    tcategoryName:'',
    tdesc: '',
    tprice: 0,
    tlocation:'',
    uploadFileNames: [],
    tDate: [],
    max_capacity:0,
};
const host = API_SERVER_HOST;

const TourReadComponent = ({ tno }) => {
    const [tour, setTour] = useState(initState);
    const { moveToList, moveToModify, page, size } = useCustomMove();
    const [currentImage, setCurrentImage] = useState(0)
    const [calendarMode, setCalendarMode] = useState('month'); // 초기 모드는 월
    const [dateInfo,setDateInfo] = useState('')
    const [fetching, setFetching] = useState(false);
    
    // calendar style
    const wrapperStyle = {
        width: 300,
        border: '1px solid #d9d9d9', 
        borderRadius: 4,
    };

    //--------------cart---------------------------------------
    //const { changeCart, cartItems } = useCustomCart();
    //const { loginState } = useCustomLogin();

    // const handleClickAddCart = () => {
    //     let qty = 1;

    //     const addedItem = cartItems.filter(item => item.tno === parseInt(tno))[0];

    //     if (addedItem) {
    //         if (window.confirm("이미 추가된 상품입니다. 추가하시겠습니까? ") === false) {
    //             return;
    //         }
    //         qty = addedItem.qty + 1;
    //     }
    //     changeCart({ email: loginState.email, tno: tno, qty: qty });
    // };

    useEffect(() => {
        setFetching(true);

        getOne(tno).then(data => {
            setTour({
                ...initState, // 초기 상태를 유지하면서
                ...data, // data의 속성들로 덮어씀
                tDate: data.tdate // tDate만 다시 설정
            });
            setFetching(false); 
            console.log(data.tdate);
        });
    }, [tno]); //tno값이 바뀔때마다 useEffect가 실행됨

    const onPanelChange = (value, mode) => {
        setCalendarMode(mode); // 현재 모드를 업데이트
        console.log(value.format('YYYY-MM-DD'), mode);
    };
    
     //예약가능한 날짜만 밑줄 생기는 함수 
     const dateCellRender = (value) => {
        const formattedDate = value.format('YYYY-MM-DD');
        const checkDate = tour.tDate.find(date => date.tourDate === formattedDate); //서버에서 받아온 날짜와 일치하는 날짜를 체크 

        return (
            <div className={`${checkDate ? 'border-b-2 border-blue-500' : ''}`}></div>  //예약 가능한 날짜에만 밑줄, 클릭가능 
        );
    };

    //예약가능한 날짜만 선택할수 있게 하는 함수 
    const disabledDate = (current) => {
        
        if (calendarMode === 'year') {
            return false; //  년도 뷰에서는 활성화
        }
    
        // 날짜 뷰일 때만 예약된 날짜가 아닌 날짜를 비활성화
        const formattedDate = current.format('YYYY-MM-DD');
        return !tour.tDate.some(date => date.tourDate === formattedDate);
    };

    // //날짜 클릭시 날짜에 해당하는 예약 가능 인원 출력하는 함수
    const onSelect = (e) => {
        console.log(e);
        console.log(e.format('YYYY-MM-DD'));
    
        const formattedDate = e.format('YYYY-MM-DD');
    
        // 예약 가능한 날짜 찾기
        setDateInfo(tour.tDate.find(i => i.tourDate === formattedDate))
    
        if (dateInfo) {
            console.log(dateInfo.tourDate); // 예약 가능한 경우, tourDate 속성만 출력
        } else {
            console.log("예약 불가"); // 예약 불가능한 경우
        }
    };

  return (
    <div className='grid grid-cols-3 gap-6 mt-10 m-4'>
    {/* Tour Details Section */}
        <Card className='col-span-2 border-2 p-4 rounded-lg shadow-md'>
            <CardHeader className="space-y-1">
                {fetching ? <FetchingModal /> : null}
                <div className='border w-20 rounded-2xl border-solid text-center font-bold mb-2'>No.{tour.tno}</div>
                <CardTitle className='text-4xl font-bold'>{tour.tname}</CardTitle>
            </CardHeader>
        {/* Tour Images */}
        <CardContent>
            <div className="space-y-4">
                <div className="aspect-square relative">
                    <img
                        src={`${host}/api/tours/view/${tour.uploadFileNames[currentImage]}`}
                        alt={tour.tname}
                        className="rounded-lg object-cover w-full h-full"
                            />
                        </div>
                        <div className="flex space-x-2">
                            {tour.uploadFileNames.map((image, index) => (
                            <button
                                key={index}
                                onClick={() => setCurrentImage(index)}
                                className={`w-20 h-20 relative rounded-md overflow-hidden ${
                                currentImage === index ? 'ring-2 ring-primary' : ''
                                }`}
                            >
                            <img
                                src={`${host}/api/products/view/${image}`}
                                alt={`${tour.tname} thumbnail ${index + 1}`}
                                className="rounded-lg object-cover w-full h-full"
                            />
                            </button>
                            ))}
                        </div>
                    </div>

        {/* Product Information */}
        <div style={wrapperStyle}>
            <Calendar
                fullscreen={false}
                onPanelChange={onPanelChange}
                cellRender={dateCellRender}
                onSelect={onSelect}
                disabledDate ={disabledDate}
            />
        </div>
        <div className='relative mb-4 flex w-full items-stretch'>
                <div className='w-4/5 p-6 rounded border border-solid shadow-md'>
                    <UserOutlined />최대 인원 : {tour.max_capacity}
                    {dateInfo ? <div>
                                    <UserOutlined />예약 가능 인원 : {dateInfo.available_capacity}</div>
                            : ''}  
                </div>
        </div>
            
        <div className='flex flex-col mt-10'>
            <div className='relative mb-4 flex w-full items-stretch'>
                <div className='w-4/5 p-6 rounded border border-solid shadow-md'>
                    <MergeOutlined />{tour.tcategoryName}
                </div>
            </div>
            <div className='relative mb-4 flex w-full items-stretch'>
                <div className='w-4/5 p-6 rounded border border-solid shadow-md'>
                    {tour.tprice.toLocaleString()}won
                </div>
            </div>
            
            <div className='relative mb-4 flex w-full items-stretch'>
                    {/* <DatePicker fullscreen={false} onPanelChange={onPanelChange} onChange={ff}/> */}
                {/* <div className='w-4/5 p-6 rounded border border-solid shadow-md'>
                    {tour.tDate}
                </div> */}
            </div>
    
            <div className='relative mb-4 flex w-full items-stretch'>
                {/* <div className='w-4/5 p-6 rounded border border-solid shadow-md'> */}
                    {tour.tdesc}
                {/* </div> */}
            </div>
        </div>

        {/* Action Buttons */}
        <div className='flex justify-end p-4 space-x-4'>
            <button
                type='button'
                className='rounded p-4 text-xl bg-gray-900 text-white hover:bg-gray-800 transition-colors duration-300'
                //onClick={handleClickAddCart}
            >
                <ShoppingCartOutlined />Add to Cart
            </button>
            <button
                type='button'
                className='rounded p-4 text-xl bg-gray-900 text-white hover:bg-gray-800 transition-colors duration-300'
                onClick={() => moveToModify(tno)}
            >
                Modify
            </button>
            <button
                type='button'
                className='rounded p-4 text-xl bg-gray-900 text-white hover:bg-gray-800 transition-colors duration-300'
                onClick={() => moveToList({ page, size })}
            >
                List
            </button>
            </div>
        </CardContent>
            
        <CardFooter className="relative justify-between">
        </CardFooter>
    </Card>
    {/* Cart Section */}
    {/* <div className='col-span-1 border-2 p-4 rounded-lg shadow-md'>
        <CartComponent />
    </div> */}
</div>
  )
}

export default TourReadComponent
